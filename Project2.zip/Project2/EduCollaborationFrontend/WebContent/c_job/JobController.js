myApp.controller("JobController",function($scope,$rootScope,$http,$location,$cookieStore)
{
	
	$scope.job={'jobId':0,'designation':'','jobDesc':'','companyName':'','skills':'','ctc':0,'experienceYears':'','isOnline':'','lastdatetoApply':''};
	
	$scope.jobs;
	
	$scope.publishJob=function()
	{
		console.log('--- I am in  Job Controller ---');
		
		$http.post('http://localhost:8080/EduCollaborationMiddleware1/publishJob',$scope.job)
		.then(function(response)
				{
					alert("Job Published");
					
				},
				function(errorresponse)
				{
					alert(" Job not  Published");
				});
	}
	
	function showAllJobs()
	{
		console.log('--- I am in  showAllJobs method ---');
		

		$http.post('http://localhost:8080/EduCollaborationMiddleware1/showAllJobs')
		.then(function(response)
				{
			       $scope.jobs=response.data;
					
				},
				function(errorresponse)
				{
					alert(" error occured");
				});
	}
	

	$scope.deletejob=function(jobId)
	{
		console.log('--- I am in  Delete Job method ---');
		
		$http.post('http://localhost:8080/EduCollaborationMiddleware1/deleteJob'+jobId)
		.then(function(response)
		{
			showAllJobs();
			alert("Job Deleted");
		},
		function(errorresponse)
		{
			alert(" error occured");
		});
	}
	
	function jobDetail()
	{
		
		
		$http.post('http://localhost:8080/EduCollaborationMiddleware1/getJob'+$rootScope.jobId1)
		.then(function(response)
		{
			$scope.job=response.data;
		},
		function(errorresponse)
		{
			alert(" error occured");
		});
	}
	
	$scope.editjob=function(jobId)
	{
		console.log('--- I am in  Edit Job method ---');
		$rootScope.jobId1=jobId;
		$location.path("/updateJob");
		
	}
	
	jobDetail();
	showAllJobs();
	
});