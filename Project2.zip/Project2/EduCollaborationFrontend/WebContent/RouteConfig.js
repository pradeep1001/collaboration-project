var myApp=angular.module("myApp",['ngRoute','ngCookies']);
myApp.config(function($routeProvider)
{
	$routeProvider.when("/login",{templateUrl:"c_user/Login.html"})
	.when("/register",{templateUrl:"c_user/Register.html"})
	.when("/aboutus",{templateUrl:"c_user/AboutUs.html"})
	.when("/contactus",{templateUrl:"c_user/ContactUs.html"})
	.when("/addBlog",{templateUrl:"c_blog/AddBlog.html"})
	.when("/showBlog",{templateUrl:"c_blog/ShowBlog.html"})
	.when("/AdminBlog",{templateUrl:"c_blog/AdminBlog.html"})
	.when("/blogComment",{templateUrl:"c_blog/BlogComment.html"})
	.when("/publishJob",{templateUrl:"c_job/PublishJob.html"})
	.when("/showJob",{templateUrl:"c_job/ShowJob.html"})
	.when("/manageJob",{templateUrl:"c_job/ManageJob.html"})
	.when("/updateJob",{templateUrl:"c_job/UpdateJob.html"})
	.when("/profileUpdate",{templateUrl:"c_user/ProfilePicture.html"})
	.when("/friend",{templateUrl:"c_friend/friend.html"})
	.when("/chat",{templateUrl:"c_chat/Chat.html"})
	.when("/userHome",{templateUrl:"c_user/UserHome.html"});
});

myApp.run(function($rootScope,$cookieStore)
		{
				if($rootScope.currentUser==undefined)
			{
			  $rootScope.currentUser=$cookieStore.get('userDetail');
			}
		});
	