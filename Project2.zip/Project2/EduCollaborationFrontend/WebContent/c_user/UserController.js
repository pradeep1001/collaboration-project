myApp.controller("UserController",function($scope,$rootScope,$http,$location,$cookieStore)
{
	$scope.user={'username':'','password':'','name':'','emailId':'','role':'','status':'','isOnline':''};
	
	$rootScope.currentUser;
	
	$scope.register=function()
	{

		console.log('I m Registering User');
		
		console.log('Username:'+$scope.user.username);
		console.log('Name :'+$scope.user.name);
		console.log('Status'+$scope.user.status);
		console.log($scope.user);

		$http.post("http://localhost:8080/EduCollaborationMiddleware1/registerUser",$scope.user)
		.then(
				function(response){
					$location.path("/login");
				},function(errorresponse)
				{
					alert('Error Occured');
				});
		
	}	
	
	$scope.logincheck=function()
	{
		console.log('------Login Information-------');
		$http.post('http://localhost:8080/EduCollaborationMiddleware1/checkUser',$scope.user)
		.then(function(response)
				{
                   $scope.user1=response.data;
                   $rootScope.currentUser=response.data;
			
                   console.log('Root Scope Data'+$rootScope.currentUser);
                   
                   $cookieStore.put('userDetail',response.data);
			        $location.path('/userHome');
			       
				},function(errorresponse)
				{
					 alert('Error Occured');	
				});
	       
			
	}
	
	$scope.logout=function()
	{
		console.log('I am in Logout Function');
		$cookieStore.remove('userDetail');
		delete $rootScope.currentUser;		
		alert("User has Logged Out");
		$location.path("/login");	
   }
	
	});