myApp.controller("BlogController",function($scope,$location,$rootScope,$http,$cookieStore)
{
	$scope.friend={'friendId':0,'username':'','friendusername':' ','status':''};
	
	$scope.friendList;
	
	$scope.pendingFriendList;
	
	$scope.suggestedFriendList;
	
	function showFriendList()
	{
		console.log('I am in FriendList');
		
		username=$rootscope.currentUser.username;
		
   	 $http.get('http://localhost:8080/EduCollaborationMiddleware1/showFriendList/'+username)
   	 .then(function(response) 
   	{
   		 $scope.friendList=response.data;
   		 console.log($scope.friendList);
   	 });		 
   }
	
	showFriendList();
   
	function showPendingFriendList()
	{
		console.log('I am in FriendList');
		
		username=$rootscope.currentUser.username;
		
   	 $http.get('http://localhost:8080/EduCollaborationMiddleware1/showPendingFriendList/'+username)
   	 .then(function(response) 
   	{
   		 $scope.pendingFriendList=response.data;
   		 console.log($scope.pendingFriendList);
   	 });		 
   }
   
	showPendingFriendList();
	
	function showSuggestionFriendList()
	{
		console.log('I am in FriendList');
		
		username=$rootscope.currentUser.username;
		
   	 $http.get('http://localhost:8080/EduCollaborationMiddleware1/showSuggestedFriendList/'+username)
   	 .then(function(response) 
   	{
   		$scope.suggestedFriendList=response.data;   		
   	 });		 
   
	}
	showSuggestionFriendList();
	
	
	$scope.sendFriendRequest=function (username)
	{
		console.log('------------ I am in Send Friend Request ------');
		
		$scope.friend.username=$rootScope.currentUser.username;
		$scope.friend.friendusername=username;
		
		
		
   	 $http.get('http://localhost:8080/EduCollaborationMiddleware1/sendFriendRequest',$scope.friend)
   	 .then(function(response) 
   	{   		
   		 console.log('------------ Friend Request Sent------');
   		showFriendList();
   		showPendingFriendList();
   		showSuggestionFriendList();
   		
   		alert('------------ Friend Request Sent------');
   	},function(errorresponse)
   	{
   		console.log('------------Error Occured------');
   		
   	 });		 
   
	}
	
	$scope.accept=function(friendId)
	{
		console.log('------------ I am in Accepting Friend Request------');
		
				
   	 $http.get('http://localhost:8080/EduCollaborationMiddleware1/acceptFriendRequest/'+friendId)
   	 .then(function(response) 
   	{   		
   		showFriendList();
   		showPendingFriendList();
   		showSuggestionFriendList();
   		alert('------------ Friend Request accepted------');
   	},function(errorresponse)
   	{
   		console.log('------------Error Occured------');
   		
   	 });		 
	 	
	}
	
	$scope.unaccept=function(friendId)
	{
		console.log('------------ I am in Unfriend------');
		
				
   	 $http.get('http://localhost:8080/EduCollaborationMiddleware1/deleteFriendRequest/'+friendId)
   	 .then(function(response) 
   	{   	
   		showFriendList();
   		showPendingFriendList();
   		showSuggestionFriendList();
   		alert('------------  Delete Friend Request------');
   	},function(errorresponse)
   	{
   		console.log('------------Error Occured------');
   		
   	 });		 
	 	
	}
	
	
});