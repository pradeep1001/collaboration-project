myApp.controller("BlogController",function($scope,$location,$rootScope,$http,$cookieStore)
{
	$scope.blog={'blogId':0,'blogName':'','blogContent':' ','username':' ','createDate':'','status':'','likes':0,"dislikes":0};
	
	$rootScope.blogdata;
	
	$scope.addBlog=function()
	{
		
		console.log('I am in Add Blog');
		$scope.blog.username=$rootScope.currentUser.username;
		$http.post('http://localhost:8080/EduCollaborationMiddleware1/addBlog',$scope.blog)
		.then(function(response)
		{
		
			alert("Blog Added Successfully");
			$scope.blog.blogName="";
			$scope.blog.blogContent="";
			$location.path("/addBlog");
		},
		function(errresponse)
		{
		
		alert("Error occured");
		
	   });
	}
	
	function listBlog()
	{
		console.log('List Blog Method');
		
		$http.get('http://localhost:8080/EduCollaborationMiddleware1/showAllBlogs')
		.then(function(response)
				{
			
			$scope.blogdata=response.data;
			console.log($scope.blogdata);
		},
		function(errorresponse){
			alert("Error occured");
		});
	}
	
	$scope.incrementLikes=function(blogId)
	{
		console.log(' I am in Increment Likes');
		
		$http.get('http://localhost:8080/EduCollaborationMiddleware1/incrementLikes/'+blogId)
		.then(function(response) 
		{
			listBlog();
			alert("Thanks for the feedback"); 
			
		 },
		 function(errorresponse) {
			 alert("Error occured");
		 });
		
	}
	$scope.incrementDisLikes=function(blogId)
	{
        console.log(' I am in Increment DisLikes');
		
		$http.get('http://localhost:8080/EduCollaborationMiddleware1/incrementLikes/'+blogId)
		.then(function(response) 
		{
			listBlog();
			alert("OOPS we are very sorry. We will go through the feedback"); 
		 },
		 function(errorresponse) {
			 alert("Error occured");
		 });
		
	}
	
	$scope.approve=function(blogId)
	{
		console.log(' I am in Approving the Blog');
		
		$http.get('http://localhost:8080/EduCollaborationMiddleware1/approveBlog/'+blogId)
		 .then(function(response) {
			 
			 listBlog();
			 alert("Blog is Approved"); 
		 },
		 function(errorresponse) {
			 alert("Error occured");
		 });
	}
	
	$scope.reject=function(blogId)
	{
		console.log(' I am in DisApproving the Blog');
		
		$http.get('http://localhost:8080/EduCollaborationMiddleware1/rejectBlog/'+blogId)
		.then(function(response) {
			 listBlog();
			 alert("Blog is Rejected"); 
		 },
		 function(errorresponse) {
			 alert("Error occured");
		 });
	}
	
	$scope.deleteBlog=function(blogId)
	{
		console.log(' I am in Deleting the Blog');
		
		$http.get('http://localhost:8080/EduCollaborationMiddleware1/deleteBlog/'+blogId)
		.then(function(response) {
			 listBlog();
			 alert("Blog is Deleted"); 
		 },
		 function(errorresponse) {
			 alert("Error occured");
		 });
	}
	
	
	$scope.showComment=function(blogId)
	{
		console.log('I am in showing comments');
		$rootScope.blogId=blogId;
		$location.path("/blogComment");
	}
	listBlog();
	
});
	