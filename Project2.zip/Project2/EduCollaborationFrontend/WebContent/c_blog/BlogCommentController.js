myApp.controller("BlogCommentController",function($scope,$location,$rootScope,$http,$cookieStore)
{
	$scope.blog={'blogId':0,'blogName':'','blogContent':' ','username':' ','createDate':'','status':'','likes':0,"dislikes":0};

	$scope.blogComments;
	
	$scope.blogComment={'commentId':0,'commentText':'','username':'','commentDate':'','blogId':0};
	
	$scope.addComment=function()
	{
		console.log('I am in add comment');
		
		$scope.blogcomment.username=$rootScope.currentUser.username;
		$scope.blogComment.blogId=$rootscope.blogId;
		
		console.log($scope.blogComments);
		
		$http.post('http://localhost:8080/EduCollaborationMiddleware1/addBlogComment',$scope.blogComment)
		.then(function(response)
				{
			       showBlog();
			       showBlogComments();
					alert("comment added");
				},
				function(errorresponse)
				{
				alert("Error occured");
				});
	}
	
	function showBlog()
	{
		console.log('I am in ShowBlog Info');
		$http.get('http://localhost:8080/EduCollaborationMiddleware1/getBlog/'+$rootScope.blogId)
		.then(function(response)
				{
					
					$scope.blog=response.data;
					console.log($scope.blog);
					
				},function(response)
				{
					 alert("Error occured");	
				});
	}
	 
	$scope.deleteComment=function(commentId)
	{
		console.log('I am in delete comment');
		
		
		$http.get('http://localhost:8080/EduCollaborationMiddleware1/deleteComment'+commentId)
		.then(function(response)
				{
					
					alert("comment deleted");
				},
				function(errresponse)
				{
					
				alert("Error occured");
				});
	}
	
	 showBlog();
	 
	 function showBlogComments()
		{
			console.log('I am in ShowBlog Comment Info');
			$http.get('http://localhost:8080/EduCollaborationMiddleware1/listBlogComments/'+$rootScope.blogId)
			.then(function(response)
					{
						
						$scope.blogComments=response.data;
						console.log($scope.blogComments);
						
					},function(response)
					{
						 alert("Error occured");	
					});
		}
	
	 showBlogComments();
	
});