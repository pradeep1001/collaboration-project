package com.coll.dao;

import com.coll.model.ProfilePicture;
import javax.transaction.Transactional;


import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Transactional
@Repository("profilePicDAO")
public class ProfilePicDAOImpl implements ProfilePicDAO
{

	

	@Autowired
	SessionFactory sessionFactory;

	public void save(ProfilePicture profilepicture)
	{
		Session session= sessionFactory.getCurrentSession();
		session.saveOrUpdate(profilepicture);
		session.flush();
	}

	public ProfilePicture getProfilePic(String username) 
	{
		Session session= sessionFactory.openSession();
		ProfilePicture profilePic = (ProfilePicture)session.get(ProfilePicture.class, username);
		session.close();
       return profilePic;
   }



}