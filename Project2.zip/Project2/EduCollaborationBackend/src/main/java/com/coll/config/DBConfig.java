package com.coll.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBuilder;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.coll.dao.BlogCommentDAO;
import com.coll.dao.BlogCommentDAOImpl;
import com.coll.dao.BlogDAO;
import com.coll.dao.BlogDAOImpl;
import com.coll.dao.FriendDAO;
import com.coll.dao.FriendDAOImpl;
import com.coll.dao.JobDAO;
import com.coll.dao.JobDAOImpl;
import com.coll.dao.UserDetailDAO;
import com.coll.dao.UserDetailDAOImpl;
import com.coll.model.Blog;
import com.coll.model.BlogComment;
import com.coll.model.Friend;
import com.coll.model.Job;
import com.coll.model.ProfilePicture;
import com.coll.model.UserDetail;


	@Configuration
	@EnableTransactionManagement
	@ComponentScan("com.coll")
	public class DBConfig 
	{
		// create a datasource object
		@Bean(name="dataSource")
	public DataSource getH2DataSource()
	{
		DriverManagerDataSource dataSource=new DriverManagerDataSource();
		dataSource.setDriverClassName("org.h2.Driver");
		dataSource.setUsername("sa");
		dataSource.setPassword("sa");
		dataSource.setUrl("jdbc:h2:tcp://localhost/~/test");
		System.out.println("=====create a datasource object===========");
		return dataSource;
	}

		
		//create a session factory object
		
		
	    @Bean(name="sessionFactory")
		public SessionFactory getSessionFactory(DataSource dataSource)
		{
	    	//System.out.println("Hibernate properties");
		Properties hibernateProperties=new Properties();
		
		hibernateProperties.put("hibernate.hbm2ddl.auto", "update");
		hibernateProperties.put("hibernate.show_sql", "true");
		hibernateProperties.put("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
		//System.out.println("Hibernate properties created");

		LocalSessionFactoryBuilder factory1=new LocalSessionFactoryBuilder(getH2DataSource());
		factory1.addProperties(hibernateProperties);
		//System.out.println("Factory builder object created");
		
		factory1.addAnnotatedClass(Blog.class);
		factory1.addAnnotatedClass(BlogComment.class);
		factory1.addAnnotatedClass(UserDetail.class);
		factory1.addAnnotatedClass(Friend.class);
		factory1.addAnnotatedClass(Job.class);
		factory1.addAnnotatedClass(ProfilePicture.class);
		

		
		SessionFactory sessionFactory=factory1.buildSessionFactory();
		System.out.println("Session factory object created");
		return sessionFactory;
		}
		
		@Bean(name="txManager")
		public HibernateTransactionManager getHibernateTransactionManager(SessionFactory sessionFactory)
		{
			System.out.println("Transaction Manager Object Created");
			return new HibernateTransactionManager(sessionFactory);
		}

	@Bean(name="userdetailDAO") 
	public UserDetailDAO getUserDetailDAO() {
		return new UserDetailDAOImpl();
	}
	@Bean(name="blogDAO") 
	public BlogDAO getBlogDAO() {
		return new BlogDAOImpl();
	}
	@Bean(name="blogcommentDAO")
	public BlogCommentDAO getBlogCommentDAO() {
		return new BlogCommentDAOImpl();
	}
	@Bean(name="friendDAO")
	public FriendDAO getFriendDAO() {
		return new FriendDAOImpl();
	}
	
	@Bean(name="jobDAO")
	public JobDAO getJobDAO() {
		return new JobDAOImpl();
	}
	
	
}
