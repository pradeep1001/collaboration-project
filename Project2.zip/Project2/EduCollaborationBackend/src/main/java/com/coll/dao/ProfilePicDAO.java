package com.coll.dao;

import com.coll.model.ProfilePicture;

public interface ProfilePicDAO {

	void save(ProfilePicture profilePicture);
	ProfilePicture getProfilePic(String email);
}




