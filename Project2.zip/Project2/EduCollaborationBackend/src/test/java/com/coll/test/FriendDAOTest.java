package com.coll.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.coll.dao.FriendDAO;
import com.coll.model.Friend;
import com.coll.model.UserDetail;

public class FriendDAOTest {

static FriendDAO friendDAO;
	
	@BeforeClass
	public static void executefirst() {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.coll");
		context.refresh();
		friendDAO=(FriendDAO)context.getBean("friendDAO");
	}
	
    @Ignore
	@Test
	public void sendfriendrequesttest() {
		Friend friend=new Friend();
		friend.setFriendId(2000);
		friend.setFriendusername("mohan");
		friend.setUsername("john");
		friend.setStatus("NA");
		assertTrue("problem in adding friend",friendDAO.sendFriendRequest(friend));
	}
	
	@Ignore
	@Test
	public void getfriendtest() {
		assertNotNull("problem in getting user",friendDAO.getFriendId(1));
	}
	
	@Ignore
	@Test
	public void acceptfriendrequesttest() {
		Friend friend=friendDAO.getFriendId(1);
		assertTrue("problem in adding friend",friendDAO.acceptFriendRequest(52));
	}
	
	@Ignore
	@Test
	public void deletefriendrequesttest() {
		Friend friend=friendDAO.getFriendId(52);
		assertTrue("problem in adding friend",friendDAO.deleteFriendRequest(52));
	}
    
    @Ignore
	@Test
	public void showfriendlisttest() {
		List<Friend> listFriends=friendDAO.showFriendList("imman");
		for(Friend friend:listFriends) {
			System.out.println("username:"+friend.getFriendusername());
		}
	}
    
	@Ignore
	@Test
	public void showpendingfriendrequesttest() {
		List<Friend> listFriends=friendDAO.showPendingFriendList("imman");
		for(Friend friend:listFriends) {
			System.out.println("username:"+friend.getFriendusername());
		}
	}
	
	@Ignore
	@Test
	public void showsuggestedfriendstest() {
		List<UserDetail> listUsers=friendDAO.showSuggestedFriend("imman");
		for(UserDetail userDetail:listUsers) {
			System.out.println("username:"+userDetail.getUsername());
		}
	}
}
