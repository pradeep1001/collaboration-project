package com.coll.test;

import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.coll.dao.BlogDAO;
import com.coll.model.Blog;

public class BlogDAOTest
{
static BlogDAO blogDAO; 
	
	@BeforeClass
	public static void executefirst()
	{
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.coll");
		context.refresh();
		
		blogDAO=(BlogDAO)context.getBean("blogDAO");
	}

	
	@Test
	public void addblogtest() {
		Blog blog=new Blog();
		
		blog.setBlogId(1002);
		blog.setBlogName("core Java");
		blog.setBlogContent("This is a simple Blog for learning core Java");
		blog.setCreateDate(new java.util.Date());
		blog.setLikes(0);
		blog.setDislikes(0);
		blog.setUsername("ranjith");
		blog.setStatus("A");
		
		assertTrue("problem in adding blog",blogDAO.addBlog(blog));
	}
	
}
