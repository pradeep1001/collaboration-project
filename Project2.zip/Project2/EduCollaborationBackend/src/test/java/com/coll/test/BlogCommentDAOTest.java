package com.coll.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.coll.dao.BlogCommentDAO;
import com.coll.model.BlogComment;
import com.coll.model.Friend;

public class BlogCommentDAOTest {

static BlogCommentDAO blogcommentDAO;
	
	@BeforeClass
	public static void executefirst() {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.coll");
		context.refresh();
		blogcommentDAO=(BlogCommentDAO)context.getBean("blogcommentDAO");
	}
	
	@Ignore
	@Test
	public void addblogcommenttest() {
		BlogComment blogcomment=new BlogComment();
		blogcomment.setBlogId(2);
		blogcomment.setCommentText("very good ");
		blogcomment.setCommentDate(new java.util.Date());
		blogcomment.setUsername("pranav");
		assertTrue("problem in adding blog comment",blogcommentDAO.addBlogComment(blogcomment));
	}

	@Ignore
	@Test
	public void getblogcommenttest() {
		assertNotNull("problem in getting blogcomment",blogcommentDAO.getBlogComment(1));
	}
	
    @Ignore
	@Test
	public void deleteblogcomment() {
		BlogComment blogcomment=blogcommentDAO.getBlogComment(52);
		assertTrue("problem in deleting blog comment",blogcommentDAO.deleteBlogComment(blogcomment));
	}
  
    @Ignore
    @Test
    public void listBlogCommentsTest()
    {
    	List<BlogComment> blogCommentsList = blogcommentDAO.listBlogComments(1);
    	assertTrue("problem in retriving blog information",blogCommentsList.size()>0);
    	for(BlogComment comment:blogCommentsList)
    	{
			System.out.println(comment.getCommentText()+":::");
			System.out.println(comment.getCommentDate());
			
		}
    }
   	
}
